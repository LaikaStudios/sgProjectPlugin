######################################################################
#  This file should be kept compatible with Python 2.3, see PEP 291. #
######################################################################
"""
Enough Mach-O to make your head spin.

See the relevant header files in /usr/include/mach-o

And also Apple's documentation.
"""

__version__ = '1.0'
